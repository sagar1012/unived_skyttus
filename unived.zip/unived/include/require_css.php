  <meta name="referrer" content="origin">
        <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<link rel="icon" type="image/png" sizes="32x32" href="logo/favicon.png">
<link rel="icon" type="image/png" sizes="96x96" href="logo/favicon.png">
<link rel="icon" type="image/png" sizes="16x16" href="logo/favicon.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link href="assets/fonts/remixicon.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="assets/css/chosen.css" />
<link rel="stylesheet" type="text/css" href="assets/css/vanilla-calendar-min.css"/>
<link rel="stylesheet" type="text/css" href="assets/css/dropzone.css"/>
<link rel="stylesheet" type="text/css" href="assets/css/style.css" /> 
<?php if(basename($_SERVER['PHP_SELF'])!="signup.php"){ ?>

<?php } ?>
<link rel="stylesheet" href="assets/css/flatpickr.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/slick.css" />
<link rel="stylesheet" href="assets/css/jquery.fancybox.css" integrity="sha512-nNlU0WK2QfKsuEmdcTwkeh+lhGs6uyOxuUs+n+0oXSYDok5qy0EI0lt01ZynHq6+p/tbgpZ7P+yUb+r71wqdXg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

