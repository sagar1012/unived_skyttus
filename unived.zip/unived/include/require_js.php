<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/chosen.jquery.min.js"></script>
<script src="assets/js/vanilla-calendar-min.js"></script>
<script src="assets/js/dropzone.js"></script>
<script src="assets/js/jquery.fancybox.min.js" integrity="sha512-uURl+ZXMBrF4AwGaWmEetzrd+J5/8NRkWAvJx5sbPSSuOb0bZLqf+tOzniObO00BjHa/dD7gub9oCGMLPQHtQA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="assets/js/script.js"></script> 
<script src="assets/js/flatpickr.js"></script>
<script src="js/custom.js"></script>