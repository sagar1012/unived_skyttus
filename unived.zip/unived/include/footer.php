<footer class="footer">
   <div class="container">
      <div class="row">
        <!--  <div class="col-md-3">
            <div class="footer-box me-md-3">
               <a href="index.html" target="_blank"><img src="assets/img/logo.png" class="footer-logo " alt="" title=""></a>
               <ul class="social-icons align-items-center mt-4">
                  <li><a href="https://www.facebook.com/PCOSCLUBINDIA" target="_blank"><i class="ri-facebook-fill"></i></a></li>
                  <li><a href="https://www.linkedin.com/company/pcos-club-india" target="_blank"><i class="ri-linkedin-fill"></i></a></li>
                  <li><a href="https://twitter.com/pcosclubindia" target="_blank"><i class="ri-twitter-fill"></i></a></li>
                  <li><a href="https://www.youtube.com/channel/UCCYUenmtx4rZB9LMek7wzkA" target="_blank"><i class="ri-youtube-fill"></i></a></li>
                  <li><a href="https://www.instagram.com/pcosclubindia/" target="_blank"><i class="ri-instagram-fill"></i></a></li>
               </ul>
            </div>
         </div> -->
         <!---col-4---->
         <!-------->
         <div class="col-md-12">
            <div class="row">
               <div class="col-lg-2 col-md-6 col-12">
                  <div class="footer-box">
                  <a href="#!"><img src="assets/img/logo.png" class="logo-footer "></a>
                 <ul class="social-icons-contact list-inline mt-md-4 mt-3">
                  <li class=""><a href="#!" target="_blank" title=""><i class="ri-facebook-fill"></i></a></li>
                   <li class=""><a href="#!" target="_blank" title=""><i class="ri-twitter-fill"></i></a></li>
                   <li class=""><a href="#!" target="_blank" title=""><i class="ri-youtube-fill"></i></a></li>
                  <li class=""><a href="#!" target="_blank" title=""><i class="ri-instagram-line"></i></a></li>
                 
                  
                 

                </ul>
                  </div>
               </div>
               <div class="col-lg-2 col-md-6 col-6">
                  <div class="footer-box">
                     <h4 class="footer-title title-with-line color-main">Unived</h4>
                     <ul class="footer-links">
                        <li><a href="#!">Our Story</a></li>
                        <li><a href="#!">Unived Teams</a></li>
                        <li><a href="#!">Our History</a></li>
                        <li><a href="#!">Why Us</a></li>
                        <li><a href="#!">Certifications</a></li>
                        <li><a href="javascript:void(0);">Career </a></li>
                     </ul>
                  </div>
               </div>
               <!------->
                 <div class="col-lg-2 col-md-6 col-6">
                  <div class="footer-box">
                     <h4 class="footer-title title-with-line color-main">Inspiration</h4>
                     <ul class="footer-links">
                        <li><a href="#!">Blog</a></li>
                        <li><a href="#!">Video</a></li>
                        <li><a href="#!">Podcast</a></li>
                        <li><a href="#!">Events</a></li>
                        <li><a href="#!">Quizzes</a></li>
                       
                     </ul>
                  </div>
               </div>
               <!------->
                 <div class="col-lg-2 col-md-6 col-6">
                  <div class="footer-box">
                     <h4 class="footer-title title-with-line color-main">Account</h4>
                     <ul class="footer-links">
                        <li><a href="#!">Sign In</a></li>
                        <li><a href="#!">Sign Up</a></li>
                        <li><a href="#!">My Account</a></li>
                        <li><a href="#!">Order History</a></li>
                       
                     </ul>
                  </div>
               </div>
               <!------->
                <div class="col-lg-2 col-md-6 col-6">
                  <div class="footer-box">
                     <h4 class="footer-title title-with-line color-main">Support</h4>
                     <ul class="footer-links">
                        <li><a href="#!">Contact Us</a></li>
                        <li><a href="#!">FAQs</a></li>
                        <li><a href="#!">Community Forum</a></li>
                        <li><a href="#!">Unived Rewards</a></li>
                       
                     </ul>
                  </div>
               </div>
               <!------->
                 <div class="col-lg col-md-6 col-12">
                  <div class="footer-box">
                     <h4 class="footer-title title-with-line color-main">Contact Us</h4>
                     <ul class="footer-links contact-us-box">
                        <li>Unit-13, Marwah Complex, Marwah Industrial Estate, Sakivihar Road, Sakinaka, Andheri East Mumbai – 400072</li>
                        <li><h6 class="color-main mb-0">Business Inquiry</h6> info@unived.in</li>
                        <li><h6 class="color-main mb-0">Customer Query</h6> wecare@unived.in
                        </li>
                      
                     </ul>
                  </div>
                  <!------->
               </div>
               <!------>

            </div>
         </div>
         <!------->
         <!------->
      </div>
   </div>
</footer>
<?php include ("include/footer_copyright.php"); ?>

   