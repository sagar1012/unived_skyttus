<header>
   <nav class="navbar navbar-expand-lg">
      <div class="container">
         <a class="navbar-brand" href="index.php"><img src="assets/img/logo.png" class="logo"></a>
       
         <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <ul class="navbar-nav mx-auto">

               <li class="nav-item">
                  <a class="nav-link" href="index.php">Home</a>
               </li>
               
               <li class="nav-item">
                  <a class="nav-link" href="javascript:;" data-bs-toggle="modal" data-bs-target="#loginmodal">Shop</a>
               </li>

               
               <li class="nav-item">
                  <a class="nav-link" href="knowledge.php">Knowledge</a>
               </li>

               <li class="nav-item">
                  <a class="nav-link" href="javascript:;" data-bs-toggle="modal" data-bs-target="#loginmodal">Experts</a>
               </li>

               <li class="nav-item">
                  <a class="nav-link" href="javascript:;" data-bs-toggle="modal" data-bs-target="#loginmodal">Community</a>
               </li>
               
            </ul>
           
             <!--   <div class="ms-md-4">
                  <li class="nav-item d-flex align-items-center">

                     <a class="nav-link link-theme py-0" href="cart.php"><i class="ri-shopping-cart-line cart-icon"></i>
                     </a>

                  </li>
                  <a class="btn btn-dark-outline ms-md-3 btn-with-icon btn-with-icon-left" href="javascript:;" data-bs-toggle="modal" data-bs-target="#loginmodal"><span>Sign In</span></a>
               </div> -->
            </div>

             <ul class="navbar-nav header-right-links flex-row align-items-center">

              <li class="nav-item">

                  <a class="nav-link link-theme py-0 search-icon" href="#!"><i class="ri-search-line"></i>
                  </a>

               </li>

               <li class="nav-item">

                  <a class="nav-link link-theme py-0 cart-icon" href="cart.php"><i class="ri-shopping-cart-line cart-icon"></i>
                  </a>

               </li>

               <li class="nav-item">
                  <a class="btn btn-dark-outline btn-login-header" href="javascript:;" data-bs-toggle="modal" data-bs-target="#loginmodal">Sign In</a>
               </li>
               
            </ul>

              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
         </button>
         </div>
      </nav>
   </header>