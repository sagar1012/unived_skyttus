<?php
$Mdb_username = 'root';
$Mdb_password = '';
$Mdb_name = 'demo_pcosclubindia';
$Mdb_host = 'localhost';
$DB_Prefix = "tbl_";

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

error_reporting(0);
?>

