<section class="banner">
   <div class="container">
      <div class="row">
         <div class="col-md-6">
            <div class="text-center">
               <img src="assets/img//veganmomy.png" height="40px" class="mb-2 veganmomy-logo">
               <h1 class="banner-title color-main">The most complete Vegan</h1>
               <div><h2 class="banner-subtitle">PRE-POSTNATAL RANGE OF NUTRITION</h2></div>
               <div class="mt-4">
                  <a href="#" class="btn btn-themesecondary">Shop Now</a>
               </div>
            </div>
         </div>
         <div class="col-md-6">

         </div>
      </div>
   </div>
</section>