<section class="section-copyright">
   <div class="container">
      <div class="row align-items-center">
         <div class="col-lg-6">
           
            <p class="mb-0 text-lg-start text-center copyright-text mx-3">Copyright &copy; 2020 Unived. All rights reserved.</p>
         </div>
         <!------>
         <div class="col-lg-6">
            <ul class="d-flex justify-content-lg-end justify-content-center list-inline copyright-links mb-0 font-secondary ">
             
               <li><a href="faqs.php" class="">FAQs</a></li>
               <li><a href="terms_of_use.php" class="">Privacy Policy </a></li>
               <li><a href="javascript:void(0);" class="">Terms & Conditions</a></li>
            </ul>
         </div>
      </div>
      <div>
      </div>
   </div>
</section>

