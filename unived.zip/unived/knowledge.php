
<!DOCTYPE html>
<html lang="en">
<head>
   <title></title>
   <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
   <?php include ("include/require_css.php"); ?>
</head>
<body>

   <?php include ("include/header.php"); ?>
   <section class="banner-inner">
      <div class="container">
         <h1 class="title color-white">Knowledge Hub</h1>
         <nav aria-label="breadcrumb">
          <ol class="breadcrumb justify-content-center breadcrumbwhite">
           <li class="breadcrumb-item"><a href="index.php">Home</a></li>
           <!--   <li class="breadcrumb-item"><a href="#!">Book Now</a></li> -->
           <li class="breadcrumb-item active color-theme" aria-current="page">Knowledge</li>
        </ol>
     </nav>
  </div>
</section><!------->




<section class="section-padding">
   <div class="container">

      <div class="title-div title-div-with-btn">
         <div>
            <h1 class="title mb-0">Recent <span class="color-theme">Posts</span></h1>
            <!--  -->
         </div>

      </div><!------->
      <div class="div-beneath-title">
         <div class="row g-4">
            <div class="col-md-3">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                  </div>
               </a>
               <h5 class="knowledge-title">Understanding Premenstrual Syndrome (Pms)</h5>

            </div><!------>

            <div class="col-md-3">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                  </div>
               </a>
               <h5 class="knowledge-title">Understanding Premenstrual Syndrome (Pms)</h5>

            </div><!------>


            <div class="col-md-3">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                  </div>
               </a>
               <h5 class="knowledge-title">Understanding Premenstrual Syndrome (Pms)</h5>

            </div><!------>

            <div class="col-md-3">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                  </div>
               </a>
               <h5 class="knowledge-title">Understanding Premenstrual Syndrome (Pms)</h5>

            </div><!------>


         </div>
      </div>
   </div>

</section><!--------->

<section class="section-padding">
   <div class="container">

      <div class="title-div title-div-with-btn">
         <div>
            <h1 class="title mb-0">Our <span class="color-theme">Blogs</span></h1>
            <!--  -->
         </div>

      </div><!------->
      <div class="div-beneath-title">
         <div class="row g-4">
            <div class="col-md-4">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                  </div>
               </a>
               <h5 class="knowledge-title ">Understanding Premenstrual Syndrome (Pms)</h5>
               <p class="line-clamp-2">While women have known about PMS since the first menstruation ever, the term was only spoken about first in 1913 by American</p>
               <ul class="list-inline ul-blogs-options border-top pt-2">
                  <li><i class="ri-eye-line"></i><span>275</span></li>
                  <li><i class="ri-chat-3-line"></i><span>238</span></li>
                  <li><i class="ri-heart-line"></i><span>195</span></li>
               </ul>
            </div><!------>

            <div class="col-md-4">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                  </div>
               </a>
               <h5 class="knowledge-title ">Understanding Premenstrual Syndrome (Pms)</h5>
               <p class="line-clamp-2">While women have known about PMS since the first menstruation ever, the term was only spoken about first in 1913 by American</p>
               <ul class="list-inline ul-blogs-options border-top pt-2">
                  <li><i class="ri-eye-line"></i><span>275</span></li>
                  <li><i class="ri-chat-3-line"></i><span>238</span></li>
                  <li><i class="ri-heart-line"></i><span>195</span></li>
               </ul>
            </div><!------>


            <div class="col-md-4">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                  </div>
               </a>
               <h5 class="knowledge-title ">Understanding Premenstrual Syndrome (Pms)</h5>
               <p class="line-clamp-2">While women have known about PMS since the first menstruation ever, the term was only spoken about first in 1913 by American</p>
               <ul class="list-inline ul-blogs-options border-top pt-2">
                  <li><i class="ri-eye-line"></i><span>275</span></li>
                  <li><i class="ri-chat-3-line"></i><span>238</span></li>
                  <li><i class="ri-heart-line"></i><span>195</span></li>
               </ul>
            </div><!------>

            <div>

            </div>


         </div>
      </div>
   </div>

</section><!--------->

<section class="section-padding">
   <div class="container">

      <div class="title-div title-div-with-btn">
         <div>
            <h1 class="title mb-0">Trending <span class="color-theme">Videos</span></h1>
            <!--  -->
         </div>

      </div><!------->
      <div class="div-beneath-title">
         <div class="row g-4">
            <div class="col-md-4">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                  </div>
               </a>
               <h5 class="knowledge-title ">Nihal Baig – Road To Ironman 70.3 World Championship</h5>

               <ul class="list-inline ul-blogs-options border-top pt-2">
                  <li><i class="ri-eye-line"></i><span>275</span></li>
                  <li><i class="ri-chat-3-line"></i><span>238</span></li>
                  <li><i class="ri-heart-line"></i><span>195</span></li>
               </ul>
            </div><!------>

            <div class="col-md-4">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                  </div>
               </a>
               <h5 class="knowledge-title ">Nihal Baig – Road To Ironman 70.3 World Championship</h5>

               <ul class="list-inline ul-blogs-options border-top pt-2">
                  <li><i class="ri-eye-line"></i><span>275</span></li>
                  <li><i class="ri-chat-3-line"></i><span>238</span></li>
                  <li><i class="ri-heart-line"></i><span>195</span></li>
               </ul>
            </div><!------>


            <div class="col-md-4">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                  </div>
               </a>
               <h5 class="knowledge-title ">Nihal Baig – Road To Ironman 70.3 World Championship</h5>

               <ul class="list-inline ul-blogs-options border-top pt-2">
                  <li><i class="ri-eye-line"></i><span>275</span></li>
                  <li><i class="ri-chat-3-line"></i><span>238</span></li>
                  <li><i class="ri-heart-line"></i><span>195</span></li>
               </ul>
            </div><!------>

            <div>

            </div>


         </div>
      </div>
   </div>

</section><!--------->

<section class="section-padding">
   <div class="container">

      <div class="title-div title-div-with-btn">
         <div>
            <h1 class="title mb-0">Our <span class="color-theme">Podcasts</span></h1>
            <!--  -->
         </div>

      </div><!------->
      <div class="div-beneath-title">
         <div class="row g-4">
            <div class="col-md-4">
               <a class="position-relative d-block knowledge-box" href="#">
                  <div class="ratio ratio-1x1 ">
                     <img src="assets/img/meditation.webp" class="w-100 object-cover dark-layer"/>
                  </div>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">Health & Wellness</h6>
                     <p class="color-white mb-0 font-size-12px">By John Doe | 14 Jun, 2021</p>
                     <h5 class="knowledge-title text-white">Nihal Baig – Road To Ironman 70.3 World Championship</h5>
                  </div>
               </a>


               
            </div><!------>


            <div>

            </div>


         </div>
      </div>
   </div>

</section><!--------->

<section class="section-padding">
   <div class="container">

      <div class="title-div title-div-with-btn">
         <div>
            <h1 class="title mb-0">Uplcoming <span class="color-theme">Events</span></h1>
            <!--  -->
         </div>

      </div><!------->
      <div class="div-beneath-title">
         <div class="row g-4">
            <div class="col-md-4">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-yellow knowledge-topic mb-0">28 NOV, 21</h6>
                     <p class="color-white mb-0 font-size-12px">10:30 AM</p>
                  </div>
               </a>
               <h5 class="knowledge-title ">Nihal Baig – Road To Ironman 70.3 World Championship</h5>
               <p>While women have known about PMS since the first menstruation ever, the term was only...</p>
               <div>
                  <a href="#" class="link link-theme link-with-icon link-with-icon-right"><span>Book Now</span><i class="ri-arrow-right-line"></i></a>
               </div>
            </div><!------>





            <div>

            </div>


         </div>
      </div>
   </div>

</section><!--------->

<section class="section-padding">
   <div class="container">

      <div class="title-div title-div-with-btn">
         <div>
            <h1 class="title mb-0">Popular <span class="color-theme">Quizzes</span></h1>
            <!--  -->
         </div>

      </div><!------->
      <div class="div-beneath-title">
         <div class="row g-4">
            <div class="col-md-4">
               <a class="position-relative d-block knowledge-box" href="#">
                  <img src="assets/img/meditation.webp" class="w-100 knowledge-img"/>
                  <div class="product-tag knowledge-tag">Blog
                  </div>
                  <div class="knowledge-div">
                     <h6 class="color-white knowledge-topic mb-0">Sed Perspiciatis Unde Omnis Iste Natus Sit</h6>
                     <p class="color-yellow mb-0 font-size-12px">8 questions</p>
                  </div>
               </a>

               
            </div><!------>





            <div>

            </div>


         </div>
      </div>
   </div>

</section><!--------->
<section class="section-subscribe">
   <div class="container">
      <div class="row">
         <div class="col-md-5">
            <h4 class="color-main mb-0">Subscribe to our Newsletter</h4>
            <p class="mb-0">Stay updated about new products and discount offers.</p>
         </div>
         <div class="col-md-5 offset-md-2">
            <div class="row">
               <div class="col-md-9 col-8">
                  <input type="email" placeholder="Email address *" required="" class="form-control mt-md-0 mt-2">
               </div>
               <div class="col-md-3 col-4">
                  <button class="btn btn-theme mt-md-0 mt-2">Subscribe</button>
               </div>
            </div>
         </div>
      </div>
   </div>
</section><!------->


<?php include ("include/footer.php"); ?>
<?php include ("include/require_js.php"); ?>




</body>
</html>